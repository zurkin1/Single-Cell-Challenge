#!/usr/bin/env Rscript
#source("~/mybiotools/r/", echo=T)
#rm(list=ls());
options("scipen"=0, "digits"=4, stringsAsFactors=FALSE);
#source("~/mybiotools/r/myfunc.R");

library(doMC)
library(doParallel)

args<-commandArgs(T)

in_rdata = args[1]
out_rdata = args[2]

source("/gpfs/ycga/project/fas/xu_ke/xz345/work/other/scdream/scripts/build_forest_predict_hpc.R")

load(in_rdata)
registerDoParallel(CPUnum)
mapping_position <- build_forest_predict_hpc     (
												  trainX,
												  trainY,
												  n_tree,
												  m_feature,
												  min_leaf,
												  CPUnum,
												  seed ,
												  cv.fold,
												  testX
												  ) 
save(mapping_position, file=out_rdata)

