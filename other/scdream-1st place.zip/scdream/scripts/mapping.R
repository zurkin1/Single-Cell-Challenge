mapping = function(geneset_input, ##gene vactor
                   bin = T,
                   num_PS,  ##number of positions want to return
				   cont.sc.84g = cont.sc.84g,
                   ...)
{
    if (!require('mccr')) {
        install.packages("mccr")
    }
	data(bin.bdt)
	#data(cont.sc.84g)
	data(bin.sc.84g)
	data(cont.bdt)
    if (bin) {
        driver0 = bin.sc.84g
        insitu0 = bin.bdt
        Method0 = "DistMap"
    } else{
        driver0 = cont.sc.84g
        insitu0 = cont.bdt
        Method0 = "pearson"
    }
    gene_idx = which(row.names(driver0) %in% geneset_input)
    test1 = driver0[gene_idx, ]
    test2 = t(insitu0)[gene_idx, ]
    acc_posi = sapply(1:ncol(test1), function(x)
        simi_dist_measures(
            test1[, x],
            test2,
            method = Method0,
            num_most_positions = num_PS
        )[[2]])
    acc_posi0 = t(acc_posi)  ### 1297 (cells) by 10 (positions) matrix
    acc_posi1 = data.frame(acc_posi0)
    rownames(acc_posi1) = colnames(driver0)
    return(acc_posi1)
}
