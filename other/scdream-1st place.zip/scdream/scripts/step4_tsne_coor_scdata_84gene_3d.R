rm(list=ls());
source("~/mybiotools/r/myfunc.R");
options("scipen"=1, "digits"=4, stringsAsFactors=FALSE);

source("/gpfs/ycga/project/fas/xu_ke/xz345/work/other/scdream/scripts/common.R", echo=T)

#library(scdream)
#data("geometry")

#load("~/scdream/method2/sc.expr.space.rdata")
data(sc.norm)
genes.84 = names(bin.bdt)
X= t(sc.norm[genes.84,])

Y=as.factor(rep("X1", dim(X)[1]))
pdffile.kw = "headtail"
pch = c(19, 15, 16, 17, 18)
cex = 1
library(RColorBrewer)
cols = brewer.pal(n = 8, name = 'RdBu')
COLOR = c(cols[1], cols[8])
COLOR = c("darkgreen", "darkblue", COLOR)

#for side bar
sidebar.values = c()
cex.axis.sidebar = 1
cex.axis = 1
cex.legend = 1
cex.lab = 1

#genes = colnames(bin.bdt)
data(DistMap_coor)
genes = names(DistMap_coor)

pdffile = "scdata_coor_84geneTsne_3d.pdf"
pdf.w = 8
pdf.h = 8

#require(parallel)
perplexitys = 8
max_iters = 6000
dims = 3

Rampcol = "Blues"

require("doParallel")
threads <- 20

### debug
#threads <- 10
#max_iters = 100
#genes = genes[1:10]
###

registerDoParallel(threads)
#all.pdffiles = c()

#genes = c("bmm")

all.pdffiles <-
	foreach (g = genes, .combine = c) %dopar%
	#foreach (g = genes[1:10], .combine = rbind) %dopar%
	{
			sidebar.values = as.numeric(DistMap_coor[, g])
			main=g
			pdffile.kw = paste0("gene_plot_", g)
			pdffile.t = paste0(g, "_grid_tsne.pdf")
			#all.pdffiles = c(all.pdffiles, pdffile.t)
			myplot_tsne(X, 
						Y, 
						main=main,
						pdffile.kw = g,
						perplexitys=perplexitys,
						max_iters=max_iters,
						pch=pch,
						cex=cex,
						COLOR=COLOR,
						sidebar.values = sidebar.values,
						cex.axis.sidebar = cex.axis.sidebar,
						cex.axis = cex.axis,
						cex.lab = cex.lab,
						cex.legend = cex.legend,
						Rampcol = Rampcol,
						dims = 3,
						sidebar.par.v = 4.5
						)
			pdffile.t
	}

#all.pdffiles = list.files(pattern="_grid_tsne")
CMD = paste0("convert ", paste(all.pdffiles, collapse=" "), " ", pdffile)
print (CMD)
system (CMD)
CMD = paste0("rm -f ", paste(all.pdffiles, collapse=" "))
print (CMD)
system (CMD)



