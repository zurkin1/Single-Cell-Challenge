#library(dplyr)
#library(scdream)

dist_evaluation=function(predicted_posi, ###predicted matrix: 1297 (cells) by 10 (predicted positions)
                           idx=T,          ###if predicted_posi is 1297 by 3 (x,y,z),idx=F
                           geometry1=geometry,      ###3039 (locations) by 3 (x,y,z)
                           gold_coor=DistMap_coor_new, ###Distmap_coor_new
                           golddat=bin.sc.84g
						   ){
#	data(bin.sc.84g)  #84 by 1297
#	data(geometry)
#	data(DistMap_coor_new)
	cellnames=colnames(golddat)
	if (idx){
		if(is.vector(predicted_posi)){
			predicted_posi1=geometry[predicted_posi,]
			rownames(predicted_posi1)=colnames(golddat)
			colnames(predicted_posi1)=c("xcoordpred", "ycoordpred", "zcoordpred")
			info<-merge(gold_coor,predicted_posi1,by.x="cell_idx",by.y="row.names",all.x=T,sort=F)
			info$scoring_cell=rep(NA,nrow(info))
			for(bb in 1:nrow(info)){
				cell_predict <- as.numeric(info[bb,colnames(predicted_posi1) ])
				DistMap_predict<-info[bb, c("xcoord", "ycoord", "zcoord")]
				dist_cell = dist(rbind(cell_predict, DistMap_predict))
				info$scoring_cell[bb]=dist_cell
			}
			info_all=info
			rownames(info_all)=NULL

			info_score=NULL
			for (kk in 1:length(cellnames)){
				info_cell=info_all[which(info_all$cell_idx==cellnames[kk]),]
				info_score_cell=mean(info_cell[,"scoring_cell"],na.rm = T)
				info_score=c(info_score,info_score_cell)
			}
			dist_all0=info_score
			scoring_cell0=dist_all0
			scoring0=mean(info_score,na.rm = T)
		}else{
			rownames(predicted_posi)=colnames(golddat)
			numcell=nrow(predicted_posi)
			numpred=ncol(predicted_posi)
			info<-merge(gold_coor,predicted_posi,by.x="cell_idx",by.y="row.names",all.x=T,sort=F)
			dist_all=NULL
			info$scoring_cell=rep(NA,nrow(info))
			for(bb in 1:nrow(info)){
				cell_predict <- geometry[as.numeric(info[bb, paste0("X", seq(1,numpred))]), ]
				DistMap_predict<-info[bb, c("xcoord", "ycoord", "zcoord")]
				dist_cell = sapply(1:nrow(cell_predict), function(x) dist(rbind(cell_predict[x,], DistMap_predict)))
				info$scoring_cell[bb]=mean(dist_cell)
				dist_all <- rbind(dist_all, dist_cell)
			}
			colnames(dist_all)=paste0("dist",seq(1,numpred))
			dist_all1=data.frame(dist_all)
			info_all=cbind(info,dist_all1)
			rownames(info_all)=NULL

			info_score=NULL
			for (kk in 1:length(cellnames)){
				info_cell=info_all[which(info_all$cell_idx==cellnames[kk]),]
				info_score_cell=colMeans(info_cell[,c("scoring_cell",colnames(dist_all))],na.rm = T)
				info_score=rbind(info_score,info_score_cell)
			}
			info_scoreall=data.frame(info_score)
			rownames(info_scoreall)=cellnames

			dist_all0=info_scoreall[,colnames(dist_all)]
			scoring_cell0=info_scoreall$scoring_cell
			scoring0=mean(info_scoreall$scoring_cell,na.rm = T)
		}
	}else{
		rownames(predicted_posi)=colnames(golddat)
		colnames(predicted_posi)=c("xcoordpred", "ycoordpred", "zcoordpred")
		info<-merge(gold_coor,predicted_posi,by.x="cell_idx",by.y="row.names",all.x=T,sort=F)
		info$scoring_cell=rep(NA,nrow(info))
		for(bb in 1:nrow(info)){
			cell_predict <- as.numeric(info[bb,colnames(predicted_posi) ])
			DistMap_predict<-info[bb, c("xcoord", "ycoord", "zcoord")]
			dist_cell = dist(rbind(cell_predict, DistMap_predict))
			info$scoring_cell[bb]=dist_cell
		}
		info_all=info
		rownames(info_all)=NULL

		info_score=NULL
		for (kk in 1:length(cellnames)){
			info_cell=info_all[which(info_all$cell_idx==cellnames[kk]),]
			info_score_cell=mean(info_cell[,"scoring_cell"],na.rm = T)
			info_score=c(info_score,info_score_cell)
		}
		dist_all0=info_score
		scoring_cell0=dist_all0
		scoring0=mean(info_score,na.rm = T)
	}
	return(list(dist_all=dist_all0,scoring_cell=scoring_cell0,scoring=scoring0))
}
