
sc24groups <- function() {
  data(cont.sc.84g)
  data(geometry)
  data(DistMap_coor)
  
  cont.sc.84g.t <- as.data.frame(t(cont.sc.84g))
  
  DistMap_coor$cell_idx <- 1:nrow(DistMap_coor)
  
  DistMap_coor$position <-
    paste(DistMap_coor$xcoord,
          DistMap_coor$ycoord,
          DistMap_coor$zcoord,
          sep = "_")
  
  geometry$position <-
    paste(geometry$xcoord,
          geometry$ycoord,
          geometry$zcoord,
          sep = "_")
  
  geometry$pos_idx <- 1:nrow(geometry)
  cell_predict <-
    merge(
      DistMap_coor[, c("cell_idx", "position", "xcoord", "ycoord", "zcoord")],
      geometry[, c("pos_idx", "position")],
      by = "position",
      all.x = T,
      sort = F
    )
  cell_predict <- cell_predict[order(cell_predict$cell_idx),]
  cont.sc.84g.t.predict <-
    cbind(cell_predict[, c("pos_idx", "xcoord", "ycoord", "zcoord")], cont.sc.84g.t)
  
  colnames(cont.sc.84g.t.predict)[ncol(cont.sc.84g.t.predict)] <-
    "pos_idx"
  
  
  cont.sc.84g.t.predict$xcoord_cut <- cut(
    cont.sc.84g.t.predict$xcoord,
    breaks = quantile(
      cont.sc.84g.t.predict$xcoord,
      probs = seq(0, 1, 0.2),
      na.rm = TRUE
    ),
    include.lowest = TRUE
  )
  
  cont.sc.84g.t.predict$zcoord_cut <- cut(
    cont.sc.84g.t.predict$zcoord,
    breaks = quantile(
      cont.sc.84g.t.predict$zcoord,
      probs = seq(0, 1, 0.2),
      na.rm = TRUE
    ),
    include.lowest = TRUE
  )
  
  cont.sc.84g.t.predict$group <-
    paste(
      as.character(cont.sc.84g.t.predict$xcoord_cut),
      as.character(cont.sc.84g.t.predict$zcoord_cut),
      sep = "_"
    )
  
  cont.sc.84g.t.predict$group_num <-
    as.numeric(as.factor(cont.sc.84g.t.predict$group))
}

