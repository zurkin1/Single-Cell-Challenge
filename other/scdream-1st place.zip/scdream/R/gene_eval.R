mapping_method <- function(genes, 
					  ifbin, 
					  mapping_method = 1, 	#1. DF, mcc, 
					  					#2. MultivariateRandomForest self training, 
					  					#3. MultivariateRandomForest training with insitu, 
					  num_PS=10,
					  CPUnum = 20,
					  cv.fold = 4, #fro cross validation in MRF
					  ... ) {
	# for evaluating genes' performance
# arg1: genes, a vector of gene symbols
# arg2: ifbin, logical to show if using binary mapping method 
# arg3: how many top results used, default 10
	#data(cont.sc.84g)
	#data(geometry)
	#data(DistMap_coor)
#	source("/gpfs/ycga/project/fas/xu_ke/xz345/work/other/scdream/scripts/common.R", echo=T)
	mapping_position = c()
	idx = F
	input_xyz = T
	n_tree=CPUnum
	m_feature=5
	min_leaf=5
	source("~/mybiotools/r/build_forest_predict_hpc.R")
	if (mapping_method == 1) {
#M4
		mapping_position = mapping(
								   geneset_input = genes,
								   bin = ifbin,
								   num_PS = num_PS,
								   cont.sc.84g = cont.sc.84g
								   )
		idx = T
		input_xyz = F
#M4 ....
	} else if ( mapping_method == 2) {
#M6
	} else if ( mapping_method == 3) {
		require (MultivariateRandomForest)
		#rownames(cont.bdt) = rownames()
		X.training = as.matrix(cont.bdt[,genes])
		Y.training = as.matrix(geometry)
		X.test = t(sc.norm)[,genes]
		mapping_position <- build_forest_predict_hpc(
										   X.training, Y.training,
										   n_tree=n_tree,
										   m_feature=m_feature,
										   min_leaf=min_leaf,
										   CPUnum = CPUnum,
										   testX=X.test)
		colnames(mapping_position) = c("xcoord", "ycoord", "zcoord")
#XYZ --> 10 idx

	} else if (mapping_method == 4) {
#including 2 mapping methods:
#1. cv.fold = NULL
#2. cv.fold = 4
		require (MultivariateRandomForest)
		X.training = as.matrix(t(cont.sc.84g)[,genes])
		Y.training = as.matrix(DistMap_coor)
		X.test =  X.training
		mapping_position <- build_forest_predict_hpc(
										   X.training, Y.training,
										   n_tree=n_tree,
										   m_feature=m_feature,
										   min_leaf=min_leaf,
										   CPUnum = CPUnum,
										   cv.fold = cv.fold,
										   testX=X.training)
		colnames(mapping_position) = c("xcoord", "ycoord", "zcoord")
#XYZ --> 10 idx

	}

	return (mapping_position)
}
