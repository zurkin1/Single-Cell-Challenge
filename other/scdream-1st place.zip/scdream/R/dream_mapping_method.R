dream_mapping_method <- function(genes,
                                 mapping_method,
                                 #1. DF, mcc, M4
                                 #2. mcc, M6
                                 #3. MultivariateRandomForest training with insitu,
                                 #4. MultivariateRandomForest self training (no CV),
                                 #5. MultivariateRandomForest self training (with CV),
                                 #6. mcc, M7
                                 #7. multiple MRF, M8
                                 num_PS = 10,
                                 seed = 123,
                                 # only used in M8
                                 CPUnum = 20,
                                 n_tree = NULL,
								 m_feature = NULL,
								 min_leaf = NULL,
                                 cv.fold = 4,
                                 #for cross validation in MRF
                                 ...) {
  # for evaluating genes' performance
  # arg1: genes, a vector of gene symbols
  # arg2: how many top results used, default 10
  #data(cont.sc.84g)
  #data(geometry)
  #data(DistMap_coor)
  #	source("/gpfs/ycga/project/fas/xu_ke/xz345/work/other/scdream/scripts/common.R", echo=T)
  mapping_position = c()
  idx = F
  input_xyz = F
  if (is.null(n_tree))
    n_tree = CPUnum
  if (is.null(m_feature)) m_feature = 5
  if (is.null(min_leaf)) min_leaf = 5

  #source("~/mybiotools/r/build_forest_predict_hpc.R")
  source("/gpfs/ycga/project/fas/xu_ke/xz345/work/other/scdream/scripts/build_forest_predict_hpc_fork.R")

  if (mapping_method == 1) {
	  mapping_position = mapping(
								 geneset_input = genes,
								 bin = T,
								 num_PS = 10,
								 cont.sc.84g = cont.sc.84g
								 )
	  mapping_new = matrix(NA, nrow(mapping_position), ncol(mapping_position))
	  for (i in 1:nrow(mapping_position)) {
		  cell_mapping = as.numeric(mapping_position[i, ])
		  posi = geometry[cell_mapping, ]
		  center_all = colMeans(posi)
		  dist_fcenter = apply(geometry, 1, function(x)
							   sqrt(sum((center_all - x) ^ 2)))
		  cell_mapping_2 = seq(1, 3039)[order(dist_fcenter, decreasing = F)][1:num_PS]
		  mapping_new[i, ] = cell_mapping_2
	  }
  } else if (mapping_method == 2) {
	  mapping_position = mapping(
								 geneset_input = genes,
								 bin = T,
								 num_PS = 30,
								 cont.sc.84g = cont.sc.84g
								 )
	  mapping_new = NULL
	  for (i in 1:nrow(mapping_position)) {
		  cell_mapping = as.numeric(mapping_position[i, ])
		  posi = geometry[cell_mapping, ]
		  dist_mat = as.matrix(dist(posi))
		  dist_sum = apply(dist_mat, 1, sum)
		  OutVals = boxplot(dist_sum, plot = FALSE)$out
		  if (length(OutVals) == 0) {
			  center_rest = colMeans(posi)
		  } else{
			  Outposi_idx = which(dist_sum %in% OutVals)
			  cell_mapping_1 = cell_mapping[-Outposi_idx]
			  posi_1 = geometry[cell_mapping_1, ]
			  center_rest = colMeans(posi_1)
		  }
		  dist_fcenter = apply(geometry, 1, function(x)
							   sqrt(sum((
										 center_rest - x
										 ) ^ 2)))
		  cell_mapping_2 = seq(1, 3039)[order(dist_fcenter, decreasing = F)][1:num_PS]
		  mapping_new = rbind(mapping_new, cell_mapping_2)
	  }
  } else if (mapping_method == 3) {
	  require (MultivariateRandomForest)
	  X.training = as.matrix(cont.bdt[, genes])
	  Y.training = as.matrix(geometry)
	  X.test = t(sc.norm)[, genes]
	  mapping_position <- build_forest_predict_hpc_fork(
														X.training,
														Y.training,
														n_tree = n_tree,
														seed = seed,
														m_feature = m_feature,
														min_leaf = min_leaf,
														CPUnum = CPUnum,
														testX = X.test
														)
	  colnames(mapping_position) = c("xcoord", "ycoord", "zcoord")

	  ##parallel on convert x,y,z to nearest 10 geometry index
	  if (is.na(pmatch("doParallel", loadedNamespaces())) &
		  is.na(pmatch("foreach", loadedNamespaces()))) {
		  if (!require(doParallel))
			  stop ("doParallel is not installed")
		  message ("Register doParallel ... ")
		  registerDoParallel(cores = CPUnum)
	  }

	  mapping_new <- foreach(i = 1:nrow(mapping_position)) %dopar% {
		  dist_fcenter = apply(geometry, 1, function(x)
							   sqrt(sum((
										 mapping_position[i, ] - x
										 ) ^ 2)))
		  cell_mapping_2 = seq(1, 3039)[order(dist_fcenter, decreasing = F)][1:num_PS]
		  cell_mapping_2
	  }

	  mapping_new <- matrix(unlist(mapping_new), ncol = num_PS, byrow = T)

  } else if (mapping_method == 4) {
	  #including 2 mapping methods:
	  #1. cv.fold = NULL
	  require (MultivariateRandomForest)
	  X.training = as.matrix(t(cont.sc.84g)[, genes])
	  Y.training = as.matrix(DistMap_coor)
	  X.test =  X.training
	  mapping_position <- build_forest_predict_hpc_fork(
														X.training,
														Y.training,
														n_tree = n_tree,
														seed = seed,
														m_feature = m_feature,
														min_leaf = min_leaf,
														CPUnum = CPUnum,
														cv.fold = NULL,
														testX = X.training
														)
	  colnames(mapping_position) = c("xcoord", "ycoord", "zcoord")

	  ##parallel on convert x,y,z to nearest 10 geometry index
	  if (is.na(pmatch("doParallel", loadedNamespaces())) &
		  is.na(pmatch("foreach", loadedNamespaces()))) {
		  if (!require(doParallel))
			  stop ("doParallel is not installed")
		  message ("Register doParallel ... ")
		  registerDoParallel(cores = CPUnum)
	  }

	  mapping_new <- foreach(i = 1:nrow(mapping_position)) %dopar% {
		  dist_fcenter = apply(geometry, 1, function(x)
							   sqrt(sum((
										 mapping_position[i, ] - x
										 ) ^ 2)))
		  cell_mapping_2 = seq(1, 3039)[order(dist_fcenter, decreasing = F)][1:num_PS]
		  cell_mapping_2
	  }

	  mapping_new <- matrix(unlist(mapping_new), ncol = num_PS, byrow = T)

  } else if (mapping_method == 5) {
	  #2. cv.fold = 4
	  require (MultivariateRandomForest)
	  X.training = as.matrix(t(cont.sc.84g)[, genes])
	  Y.training = as.matrix(DistMap_coor)
	  X.test =  X.training
	  mapping_position <- build_forest_predict_hpc_fork(
														X.training,
														Y.training,
														n_tree = n_tree,
														seed = seed,
														m_feature = m_feature,
														min_leaf = min_leaf,
														CPUnum = CPUnum,
														cv.fold = cv.fold,
														testX = X.training
														)
	  colnames(mapping_position) = c("xcoord", "ycoord", "zcoord")

	  ##parallel on convert x,y,z to nearest 10 geometry index
	  if (is.na(pmatch("doParallel", loadedNamespaces())) &
		  is.na(pmatch("foreach", loadedNamespaces()))) {
		  if (!require(doParallel))
			  stop ("doParallel is not installed")
		  message ("Register doParallel ... ")
		  registerDoParallel(cores = CPUnum)
	  }

	  mapping_new <- foreach(i = 1:nrow(mapping_position)) %dopar% {
		  dist_fcenter = apply(geometry, 1, function(x)
							   sqrt(sum((
										 mapping_position[i, ] - x
										 ) ^ 2)))
		  cell_mapping_2 = seq(1, 3039)[order(dist_fcenter, decreasing = F)][1:num_PS]
		  cell_mapping_2
	  }

	  mapping_new <- matrix(unlist(mapping_new), ncol = num_PS, byrow = T)

  } else if (mapping_method == 6) {
	  mapping_position = mapping(
								 geneset_input = genes,
								 bin = T,
								 num_PS = 30,
								 cont.sc.84g = cont.sc.84g
								 )
	  mapping_new = NULL
	  for (i in 1:nrow(mapping_position)) {
		  cell_mapping = as.numeric(mapping_position[i, ])
		  posi = geometry[cell_mapping, ]
		  dist_mat = as.matrix(dist(posi))
		  dist_sum = apply(dist_mat, 1, sum)
		  OutVals = boxplot(dist_sum, plot = FALSE)$out
		  if (length(OutVals) == 0) {
			  cell_mapping_single = cell_mapping[1:num_PS]
		  } else{
			  Outposi_idx = which(dist_sum %in% OutVals)
			  cell_mapping_single = cell_mapping[-Outposi_idx][1:num_PS]
		  }
		  mapping_new = rbind(mapping_new, cell_mapping_single)
	  }
  } else if (mapping_method == 7) {
	  mapping_new = c()
	  n.num = ncol(mapping_new)
	  if (is.null(n.num)){
		  n.num<-0
	  } 
	  require (MultivariateRandomForest)
	  set.seed(seed)
	  seeds = sample(1:10000)
	  i = 1
	  while (n.num < num_PS) {
		  message (paste0("Cycle No. ", i, "; ncol of positoin: ", n.num))
		  #set.seed(seeds[i])
		  i = i + 1
		  X.training = as.matrix(t(cont.sc.84g)[, genes])
		  Y.training = as.matrix(DistMap_coor)
		  X.test =  X.training
		  mapping_position <- build_forest_predict_hpc_fork(
															X.training,
															Y.training,
															n_tree = n_tree,
															seed = seed,
															m_feature = m_feature,
															min_leaf = min_leaf,
															CPUnum = CPUnum,
															cv.fold = NULL,
															seed = seeds[i],
															testX = X.training
															)
		  colnames(mapping_position) = c("xcoord", "ycoord", "zcoord")

		  ##parallel on convert x,y,z to nearest 10 geometry index
		  if (is.na(pmatch("doParallel", loadedNamespaces())) &
			  is.na(pmatch("foreach", loadedNamespaces()))) {
			  if (!require(doParallel))
				  stop ("doParallel is not installed")
			  message ("Register doParallel ... ")
			  registerDoParallel(cores = CPUnum)
		  }

		  mapping_new.temp <- foreach(i = 1:nrow(mapping_position)) %dopar% {
			  dist_fcenter = apply(geometry, 1, function(x)
								   sqrt(sum((
											 mapping_position[i,] - x
											 ) ^ 2)))
			  cell_mapping_2 = seq(1, 3039)[order(dist_fcenter, decreasing = F)][1]
			  cell_mapping_2
		  }

		  if (F) {
			  check_dup <- function (v1) {
				  any(v1 == mapping_new.temp)
			  }
			  if (!is.null(dim(mapping_new))) {
				  check.res = apply(mapping_new, 2, check_dup)
			  } else {
				  check.res = F
			  }
		  }
		  #if (sum(check.res)==0) mapping_new <- cbind(mapping_new, mapping_new.temp)
		  mapping_new <- cbind(mapping_new, mapping_new.temp)
		  n.num = ncol(mapping_new)
		  n.num 

	  }
  }

  rownames(mapping_new) = colnames(cont.sc.84g)
  mapping_new = data.frame(mapping_new)

  return (mapping_new)
}
