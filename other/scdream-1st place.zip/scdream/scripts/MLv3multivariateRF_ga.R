#run:  pbsv2.pl -q bigmem -pmem 100000 -e -wt 7- "runR.sh ~/mybiotools/r/make_cluster_example.R"
#post: pbsv2.pl "Rscript --slave ~/scdream/scripts/eval_genes.R GA_glmnet_maxiter10_g15_run5_popSize120_MLMRF_ga.rdata > g15.txt"

library(caret)
library(GA)
library(MultivariateRandomForest)
#library(pROC)

load("../xcoord.rdata")
load("../ycoord.rdata")
load("../zcoord.rdata")

method = "MRF"
out.rdata.file = paste0("GA_glmnet_maxiter", maxiter, "_g", select.num, "_run", run, "_popSize", popSize, "_ML", method, "_tree", n_tree, "_ga.rdata")
out.pdf = 		 paste0("GA_glmnet_maxiter", maxiter, "_g", select.num, "_run", run, "_popSize", popSize, "_ML", method, "_tree", n_tree, "_ga.pdf")

seed = select.num + popSize + maxiter + run
ifparallel = cl
save (cl, file="cl.rdata")
nBits = ncol(X)

library(scdream)
data(DistMap_coor_new)
data(bin.bdt)
data(bin.sc.84g)
data(cont.bdt)
data(geometry)
data(geometry.all)
data(sc.norm)
data(sc.norm.quant)
data(sc.raw)
data(DistMap_coor)
data(gene_subset_summary)
genes.84 = names(bin.bdt)
cont.sc.84g = sc.norm.quant[genes.84,]
geometry1 = geometry


fitness.ml <- function (bin, method="glmnet") {
	#debug
	# bin = sample(c(rep(0, 24), rep(1, 60)), replace = F)
# load("~/GA/g20_ifbinTRUE_ga.rdata")
# bin = GA@solution
	s.i = which(bin == 1)
	X.test = as.matrix(X[, s.i])
	Y.test = cbind(xcoord=Y1, ycoord=Y2, zcoord=Y3)

	pp = c("center", "scale")

	#n_tree=100
	#m_feature=as.integer(ncol(X.test)/4)
	#min_leaf=as.integer(nrow(X.test)/100)
#	n_tree=CPUnum
#	m_feature=5
#	min_leaf=5
	
	source("~/mybiotools/r/build_forest_predict_hpc.R")
	prediction <- build_forest_predict_hpc(
								  X.test, Y.test, 
								  n_tree=n_tree, 
								  m_feature=m_feature, 
								  min_leaf=min_leaf, 
								  testX=X.test,
								  CPUnum=CPUnum)

	colnames(prediction) = c("xcoord", "ycoord", "zcoord")
	mapping_position = prediction

	source("/gpfs/ycga/project/fas/xu_ke/xz345/soft/git/scdream/R/simi_dist_measures.R")
	source("/gpfs/ycga/project/fas/xu_ke/xz345/soft/git/scdream/R/dist_evaluation.R")
	source("/gpfs/ycga/project/fas/xu_ke/xz345/soft/git/scdream/scripts/mapping.R")
	evalu.out = dist_evaluation(predicted_posi = mapping_position,
								idx=F,
								geometry1=geometry1,
								golddat=bin.sc.84g,
								gold_coor=DistMap_coor_new)
	-1*evalu.out$scoring
}

#for ga relative functions
source("/gpfs/ycga/project/fas/xu_ke/xz345/soft/git/scdream/R/ga_func.R")

####
clusterExport(cl, varlist = c("min_leaf", "m_feature", "n_tree", "CPUnum", "DistMap_coor_new", "bin.sc.84g", "geometry1", "DistMap_coor", "X", "Y1", "Y2", "Y3", "fitness.ml", "initial_population", "monitor_check_genenum", "monitor_check_genenum", "select_pop", "crossover_pop", "mutat_pop"))
clusterCall(cl, library, package = "caret", character.only = TRUE)
clusterCall(cl, library, package = "MultivariateRandomForest", character.only = TRUE)
####

GA <- ga(
		 type = "binary",
		 fitness = fitness.ml,
		 population = initial_population,
		 monitor = monitor_check_genenum,
		 selection = select_pop,
		 crossover = crossover_pop,
		 mutation = mutat_pop,
		 popSize = popSize,
		 keepBest = keepBest,
		 parallel = ifparallel,
		 maxiter = maxiter,
		 run =  run,
		 seed = seed,
		 maxFitness = maxFitness,
		 pmutation = pmutation,
		 pcrossover = pcrossover,
		 method = method,
		 nBits = nBits
		 )

summary(GA)
s = GA@solution
rowSums(s)
s = GA@population
rowSums(s)

if (!debug) {
	save (GA, file=out.rdata.file)
	pdf(out.pdf)
	plot(GA)
	dev.off()
}
