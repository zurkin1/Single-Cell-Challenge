rm(list=ls());
#source("~/mybiotools/r/myfunc.R");
options("scipen"=1, "digits"=4, stringsAsFactors=FALSE);

library(scdream)
data(bin.bdt)

library(gtools)
genes = names(bin.bdt)
#g.comb = combn(84, 20)

if (!file.exists("gene.comb.20.rdata")) {
	gene.comb.20 = combinations(84, 20, genes,repeats.allowed=F)
	save(gene.comb.20, file="gene.comb.20.rdata")
} else {
	load("gene.comb.20.rdata")
}
if (!file.exists("gene.comb.40.rdata")) {
	gene.comb.40 = combinations(84, 40, genes,repeats.allowed=F)
	save(gene.comb.40, file="gene.comb.40.rdata")
} else {
	load("gene.comb.40.rdata")
}
if (!file.exists("gene.comb.60.rdata")) {
	gene.comb.60 = combinations(84, 60, genes,repeats.allowed=F)
	save(gene.comb.60, file="gene.comb.60.rdata")
} else {
	load("gene.comb.60.rdata")
}

gene.bin.num <- function(genes, bin.bdt) {
    dat = bin.bdt[, genes]
    dat$merged = apply(dat, 1, function(x) {
        paste(x, collapse = "")
    })
    bin.unique = unique(dat$merged)
    length(bin.unique)
}

# require("parallel")
require (future.apply)
plan(multiprocess)
# CPUnum = 2

g.bin.num = future_apply(gene.comb.20, 1, gene.bin.num, bin.bdt)
names(g.bin.num) = 1:nrow(gene.comb.20)
g.bin.num.s = sort(g.bin.num, decreasing =T)
print ("Maximum bin:")
print (g.bin.num.s[1])
table(g.bin.num.s)
head(g.bin.num.s)

g.bin.num = future_apply(gene.comb.40, 1, gene.bin.num, bin.bdt)
names(g.bin.num) = 1:nrow(gene.comb.40)
g.bin.num.s = sort(g.bin.num, decreasing =T)
print ("Maximum bin:")
print (g.bin.num.s[1])
table(g.bin.num.s)
head(g.bin.num.s)

g.bin.num = future_apply(gene.comb.60, 1, gene.bin.num, bin.bdt)
names(g.bin.num) = 1:nrow(gene.comb.60)
g.bin.num.s = sort(g.bin.num, decreasing =T)
print ("Maximum bin:")
print (g.bin.num.s[1])
table(g.bin.num.s)
head(g.bin.num.s)

