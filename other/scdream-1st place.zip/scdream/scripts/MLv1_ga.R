#run:  pbsv2.pl -q bigmem -pmem 100000 -e -wt 7- "runR.sh ~/mybiotools/r/make_cluster_example.R"

library(caret)
library(GA)
#library(pROC)

load("../xcoord.rdata")
load("../ycoord.rdata")
load("../zcoord.rdata")

out.rdata.file = paste0("GA_glmnet_maxiter", maxiter, "_g", select.num, "_run", run, "_popSize", popSize, "_ML", method, "_ga.rdata")
out.pdf = 		 paste0("GA_glmnet_maxiter", maxiter, "_g", select.num, "_run", run, "_popSize", popSize, "_ML", method, "_ga.pdf")

seed = select.num + popSize + maxiter + run
ifparallel = cl
nBits = ncol(X)

fitness.ml <- function (bin, method="glmnet") {
	#debug
	# bin = sample(0:1, nBits, replace = T, prob=c(24/84,60/84))
	s.i = which(bin == 1)
	X.test = X[, s.i]

	#method = "glmnet"
	metric = "RMSE"
	tuneLength = 2
	repeats = 1
	pp = c("center", "scale")
	ctrl_method = "repeatedcv"
	mysummaryFunction = defaultSummary
	classProbs = F
	savePredictions = "final"
	casecontrol = F
	#allowParallel = T
	#method = "glmnet"
	#metric = "ROC"
	tuneLength = 1
	pp = c("center", "scale")

	source("~/git/smartFeatureSelection/R/fineTuning.R")
	# caret para
	get_rmse <- function (X.test, Y.test) {
		train.model <-
			fineTuning(
					   X = X.test,
					   Y = Y.test,
					   ctrl_method = ctrl_method,
					   method = method,
					   metric = metric,
					   tuneLength = tuneLength,
					   repeats = repeats,
					   classProbs = classProbs,
					   mysummaryFunction = mysummaryFunction,
					   savePredictions = savePredictions,
					   casecontrol = casecontrol,
					   pp = pp
					   )
		min(train.model$results$RMSE, na.rm=T)
	}

	Y.test = Y1
	RMSE1 = get_rmse (X.test, Y.test)
	Y.test = Y2
	RMSE2 = get_rmse (X.test, Y.test)
	Y.test = Y3
	RMSE3 = get_rmse (X.test, Y.test)

	RMSE = RMSE1 + RMSE2 + RMSE3
	#as.numeric(out.auc)
	as.numeric(-1 * RMSE)
}

#for ga relative functions
source("~/git/scdream/R/ga_func.R")

####
clusterExport(cl, varlist = c("X", "Y1", "Y2", "Y3", "fitness.ml", "initial_population", "monitor_check_genenum", "monitor_check_genenum", "select_pop", "crossover_pop", "mutat_pop"))
clusterCall(cl, library, package = "caret", character.only = TRUE)
####

GA <- ga(
		 type = "binary",
		 fitness = fitness.ml,
		 population = initial_population,
		 monitor = monitor_check_genenum,
		 selection = select_pop,
		 crossover = crossover_pop,
		 mutation = mutat_pop,
		 popSize = popSize,
		 keepBest = keepBest,
		 parallel = ifparallel,
		 maxiter = maxiter,
		 run =  run,
		 seed = seed,
		 maxFitness = maxFitness,
		 pmutation = pmutation,
		 pcrossover = pcrossover,
		 method = method,
		 nBits = nBits
		 )

summary(GA)
s = GA@solution
rowSums(s)
s = GA@population
rowSums(s)

if (!debug) {
	save (GA, file=out.rdata.file)
	pdf(out.pdf)
	plot(GA)
	dev.off()
}
