# gtc2018-numba
Numba tutorial for GTC 2018 conference

Docker instructions in the `docker` directory.
