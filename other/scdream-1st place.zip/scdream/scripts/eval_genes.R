#!/usr/bin/env Rscript
#using GA / tsne to find best gene sets among all 9000 genes

rm(list=ls());
options("scipen"=1, "digits"=4, stringsAsFactors=FALSE);

args<-commandArgs(T)

#select.num = as.numeric(args[1])
#ifbin = as.logical(args[2])
rdataf = args[1]

source("/gpfs/ycga/project/fas/xu_ke/xz345/work/other/scdream/scripts/common.R")

load_obj <- function(f)
{
	env <- new.env()
	nm <- load(f, env)[1]
	env[[nm]]
}

##debug###
if (F) {
	rdataf = "tsneGA_g40_ifbinFALSE_maxiter500_run80_popSize100_ga.rdata"
	rdataf = "../g40_ifbinFALSE_ga.rdata"
	rdataf = "../tsne_GA/tsneGA_g60_ifbinFALSE_maxiter1500_run150_popSize100_ga.rdata"
	rdataf = "../tsne_GA/tsneGA_g40_ifbinFALSE_maxiter1500_run150_popSize100_ga.rdata"
	rdataf = "~/GA/g40_ifbinTRUE_ga.rdata"

	rdataf = "GA_glmnet_maxiter1000_g60_run20_popSize120_MLMRF_tree5_ga.rdata"
}


ga = load_obj(rdataf)
library(scdream)
data(bin.bdt)
genes.84 = colnames(bin.bdt)
genes = genes.84[which(ga@solution == 1)]
ifbin=T
num_PS=10

mm = c(1,2,4,5) # mapping method
n_tree = 5
CPUnum = 20

library(doParallel)
registerDoParallel(cores = CPUnum)

output = c()
#for (m in mm) {
output <- foreach (i = 1:length(mm), .combine = c) %dopar%
{
	m = mm[i]
	mapping_position = dream_mapping_method(genes=genes,
											mapping_method= m,
											CPUnum = 5,
											n_tree = n_tree,
											num_PS = 10
											)
	evalu.out = dist_evaluation(predicted_posi = mapping_position,
								idx=T,
								geometry1=geometry1,
								golddat=bin.sc.84g,
								gold_coor=DistMap_coor_new)
	allcorr = c()
	for (ncol in 1:ncol(mapping_position)) {
		e.corr = eval_corr(mapping_position,
				  ncol = ncol,
				  method = "bin",
				  input_xyz = F
				  )
		allcorr = c(allcorr, e.corr)
	}
	corr.v = mean(allcorr, na.rm=T)
	score.v = evalu.out$scoring
	c(score.v, corr.v)
}

nn =  expand.grid(c("Dist.score", "Pos.corr"), c("M4", "M6", "MRFnoCV", "MRFwithCV"))
nn2 = paste0(nn[,2], "_", nn[,1])
names(output) =  nn2
output



