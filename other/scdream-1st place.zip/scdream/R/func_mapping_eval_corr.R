##mapping and evaluation by correlation

###MCC
computeMCC <- function(genes, cell) {
  mtrx <- -sweep(bin.bdt[, genes], 2, 2 * bin.sc.84g[genes, cell], '-')
  FP = rowSums(mtrx == 2)
  TP = rowSums(mtrx == 1)
  TN = rowSums(mtrx == 0)
  FN = rowSums(mtrx == -1)
  denom <- as.double(TP + FP) * (TP + FN) * (TN + FP) * (TN + FN)
  denom[which(denom==0)] <- 1
  mcc <- ((TP * TN) - (FP * FN))/sqrt(denom)
  return (mcc)
}




###distmap mapping
mapping_distmap <- function(genes, num_max) {
  mcc.scores <- sapply(1:ncol(bin.sc.84g), function(cell)
    computeMCC(genes, cell))
  
  rownames(mcc.scores) <- 1:nrow(mcc.scores)
  colnames(mcc.scores) <- colnames(bin.sc.84g)
  
  position <-
    apply(mcc.scores, 2, function(i)
      sort(i, decreasing = T, index.return = TRUE)$ix[1:num_max])
  
  #write function for averaging multiple input
  if (num_max == 1) {
    output <- cbind(position, geometry[position, ])
  }
}

###eval_corr (continous)
eval_corr_cont<-function(output_mapping) {
  #merge
  predict_cont_gene_pos_matrix<-merge(output_mapping,as.data.frame(t(cont.sc.84g)),by="row.names",sort=F,all.x=T)
  
  #calculate correlation matrix
  col_num<-ncol(output_mapping)
  predict_cont_corr_matrix<-cor(predict_cont_gene_pos_matrix[, c("xcoord","ycoord","zcoord")], predict_cont_gene_pos_matrix[, (col_num+2):ncol(predict_cont_gene_pos_matrix)])
  
  #compare with gold standard
  compare<-abs(predict_cont_corr_matrix)-abs(gold_cont_corr_matrix)
  return(compare)
}

###eval_corr (binary)
eval_corr_bin<-function(output_mapping) {
  #merge
  predict_bin_gene_pos_matrix<-merge(output_mapping,as.data.frame(t(bin.sc.84g)),by="row.names",sort=F)
  
  #calculate correlation matrix
  col_num<-ncol(output_mapping)
  predict_bin_corr_matrix<-cor(predict_bin_gene_pos_matrix[, c("xcoord","ycoord","zcoord")], predict_bin_gene_pos_matrix[, (col_num+2):ncol(predict_bin_gene_pos_matrix)])
  
  #compare with gold standard
  compare<-abs(predict_bin_corr_matrix)-abs(gold_bin_corr_matrix)
  return(compare)
}




