###eval_corr (binary, continous) updated 11/13
eval_corr <- function(dat,
                      ncol=10,
                      genes = NULL,
                      method = "bin",
                      input_xyz = F) {
  stopifnot (method %in% c("bin", "cont"))
  stopifnot(ncol %in% c(1:100))
  
  if (method == "bin") {
    gold.data <- t(bin.sc.84g)
    gold.data.bdt <- bin.bdt 
  } else if (method == "cont") {
    gold.data <- t(cont.sc.84g)
    gold.data.bdt <- cont.bdt 
  }
  
  stopifnot(nrow(dat) == nrow(gold.data))
  if (is.null(genes)) {
    selected_genes <- colnames(cont.bdt)
  } else {
    stopifnot(genes %in% colnames(cont.bdt))
    selected_genes <- genes
  }
  
  if (input_xyz == F) {

    compare.expr<-c()
    
    for (col in 1:ncol) {
      output_mapping <-
        data.frame(position = dat[, col], row.names = row.names(dat))
      
      compare.bdt<-gold.data.bdt[output_mapping$position,selected_genes]
      compare.pred<-gold.data[, selected_genes]
      
      compare.expr.mat<-diag(cor(compare.bdt,compare.pred))
      
      compare.expr<-c(compare.expr,mean(compare.expr.mat))
    }

    return(mean(compare.expr))

  } else {
    stopifnot(ncol(dat) == 3)
    predict_corr_matrix <- cor(dat, gold.data)
    value <- mean(predict_corr_matrix, na.rm = TRUE)
    return(value)
  }
}
