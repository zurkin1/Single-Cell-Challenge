#using permutations instead of combinations

rm(list=ls());
#source("~/mybiotools/r/myfunc.R");
options("scipen"=1, "digits"=4, stringsAsFactors=FALSE);

library(scdream)
data(bin.bdt)

library(gtools)
genes = names(bin.bdt)
#g.comb = combn(84, 20)

gene.bin.num <- function(genes, bin.bdt) {
	dat = bin.bdt[, genes]
	dat$merged = apply(dat, 1, function(x) {
					   paste(x, collapse = "")
})
	bin.unique = unique(dat$merged)
	length(bin.unique)
}

# require("parallel")
# CPUnum = 2

get_max_bin <- function (seeds=1:1000, #seed number
						 CPUnum = 30,
						 gene.num = 20,
						 fun = gene.bin.num,
						 bin.bdt = bin.bdt,
						 ...) {
	library(doParallel)
	registerDoParallel(cores = CPUnum)
	n = length(seeds)
	#n = num.comb.max
	#blocksize = as.integer(n / (CPUnum + 1)) + 1
	blocksize = CPUnum * 2
	blocksize = ifelse (blocksize<n, blocksize, n)
	pos = as.integer(seq(1, n, length.out=blocksize))
	pos[length(pos)] = n + 1
	block_num = length(pos) - 1
	#message ("Block number: ", block_num, "\n")
	#start: pos[-length(pos)] 
	#end:   pos[-1]-1
	output <- foreach (j = 1:block_num, .combine = rbind) %dopar%
	{
		start = pos[j]
		end = pos[j + 1] - 1
		out.s = c()
		for (i in start:end) {
			seed = seeds[i]
			set.seed(seed)
			gene.l = sample(genes, gene.num, replace=F)
			max.num = fun(gene.l, bin.bdt)
			out.s = rbind(out.s, c(seed, max.num))
		}
		colnames(out.s) = c("seed", "max.bin.num")
		out.s
	}
	max.bin = max(output[,2])
	max.i = which(output[,2] == max.bin)
	max.seed = output[max.i[1], 1]
	set.seed(max.seed)
	max.gene.l = sample(genes, gene.num, replace=F)
	return (list(gene=max.gene.l, max.bin = max.bin))
}

makeblock <- function (
					   max.d,
					   CPUnum = 20,
					   min.d = 1,
					   ...) {
	n = max.d
	blocksize = CPUnum * 2
	blocksize = ifelse (blocksize<n, blocksize, n)
	pos = as.integer(seq(min.d, n, length.out=blocksize))
	pos[length(pos)] = n + 1
	block_num = length(pos) - 1
	#return (list(block_num = block_num, start = pos[-length(pos)], end = pos[-1]-1), pos = pos)
	return (list(block_num = block_num, start = pos[-length(pos)], end = pos[-1]-1, pos = pos))
}


##########parameters###############
min.seed = 1
CPUnum = 30
max.seed = 10000000
min.seed = 2000000
CPUnum = 20
max.seed = 4000000
block.out = makeblock(max.seed, CPUnum, min.seed)
if (F) {
n = max.seed
blocksize = CPUnum * 2
blocksize = ifelse (blocksize<n, blocksize, n)
pos = as.integer(seq(min.seed, n, length.out=blocksize))
pos[length(pos)] = n + 1
block_num = length(pos) - 1
}
block_num = block.out$block_num
pos = block.out$pos
##########parameters###############

do_max <- function(l) {
	m = do.call(c, l[[2]])
	max(m)
}

gene.num = 60
l.g60 = vector("list", 2)
l.g60[[1]] = list()
l.g60[[2]] = list()
names(l.g60) = c("gene", "max.bin.num")
for (j in 1:block_num)
{
	start = pos[j]
	end = pos[j + 1] - 1
	seeds = start:end
	print (paste0("Gene.num: ", gene.num, "; block: ", start, ":", end))
	max.out = get_max_bin(seeds=seeds, CPUnum=CPUnum, gene.num=gene.num, fun=gene.bin.num, bin.bdt)
	l.g60[[1]][[length(l.g60[[1]])+1]] = max.out[[1]]
	l.g60[[2]][[length(l.g60[[2]])+1]] = max.out[[2]]
	print (do_max(l.g60))
}
save(l.g60, file=paste0(min.seed, "_", max.seed, "_l.g60.rdata"))

gene.num = 40
l.g40 = vector("list", 2)
l.g40[[1]] = list()
l.g40[[2]] = list()
names(l.g40) = c("gene", "max.bin.num")
for (j in 1:block_num)
{
	start = pos[j]
	end = pos[j + 1] - 1
	seeds = start:end
	print (paste0("Gene.num: ", gene.num, "; block: ", start, ":", end))
	max.out = get_max_bin(seeds=seeds, CPUnum=CPUnum, gene.num=gene.num, fun=gene.bin.num, bin.bdt)
	l.g40[[1]][[length(l.g40[[1]])+1]] = max.out[[1]]
	l.g40[[2]][[length(l.g40[[2]])+1]] = max.out[[2]]
	print (do_max(l.g40))
}
save(l.g40, file=paste0(min.seed, "_", max.seed, "_l.g40.rdata"))

gene.num = 20
l.g20 = vector("list", 2)
l.g20[[1]] = list()
l.g20[[2]] = list()
names(l.g20) = c("gene", "max.bin.num")
for (j in 1:block_num)
{
	start = pos[j]
	end = pos[j + 1] - 1
	seeds = start:end
	print (paste0("Gene.num: ", gene.num, "; block: ", start, ":", end))
	max.out = get_max_bin(seeds=seeds, CPUnum=CPUnum, gene.num=gene.num, fun=gene.bin.num, bin.bdt)
	l.g20[[1]][[length(l.g20[[1]])+1]] = max.out[[1]]
	l.g20[[2]][[length(l.g20[[2]])+1]] = max.out[[2]]
	print (do_max(l.g20))
}
save(l.g20, file=paste0(min.seed, "_", max.seed, "_l.g20.rdata"))


if (F) {
	require (future.apply)
	plan(multiprocess)
	g.bin.num = future_apply(gene.comb.20, 1, gene.bin.num, bin.bdt)
	names(g.bin.num) = 1:nrow(gene.comb.20)
	g.bin.num.s = sort(g.bin.num, decreasing =T)
	print ("Maximum bin:")
	print (g.bin.num.s[1])
	table(g.bin.num.s)
	head(g.bin.num.s)

	g.bin.num = future_apply(gene.comb.40, 1, gene.bin.num, bin.bdt)
	names(g.bin.num) = 1:nrow(gene.comb.40)
	g.bin.num.s = sort(g.bin.num, decreasing =T)
	print ("Maximum bin:")
	print (g.bin.num.s[1])
	table(g.bin.num.s)
	head(g.bin.num.s)

	g.bin.num = future_apply(gene.comb.60, 1, gene.bin.num, bin.bdt)
	names(g.bin.num) = 1:nrow(gene.comb.60)
	g.bin.num.s = sort(g.bin.num, decreasing =T)
	print ("Maximum bin:")
	print (g.bin.num.s[1])
	table(g.bin.num.s)
	head(g.bin.num.s)
}
