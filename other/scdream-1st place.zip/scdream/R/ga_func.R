
#library(GA)
#library(doParallel)

initial_population <- function(ga.o) {
	popSize = ga.o@popSize
	nBits = ga.o@nBits
	out = c()
	for (j in 1:popSize) {
		s.i = sample(1:nBits, select.num, replace = F)
		l = rep(0, nBits)
		l[s.i] = 1
		out = rbind(out, l)
	}
	out
}

monitor_check_genenum <- function (object, digits = getOption("digits"), ...) 
{
	fitness <- na.exclude(object@fitness)
	sumryStat <- c(mean(fitness), max(fitness))
	sumryStat <- format(sumryStat, digits = digits)
	#s = object@population
	#r.sum = rowSums(s)
	cat(paste("GA | iter =", object@iter, "| Mean =", sumryStat[1], 
			  "| Best =", sumryStat[2],
			  #" | Population =", paste0(s, collapse=""),
			  "\n"))
	save(object, file="temp.GA.object.rdata")
}

get_best_pop <- function (object) {
	fitness <- na.exclude(object@fitness)
	best.i = which(fitness == max(fitness))
	message (paste0("Best fitness: ", max(fitness)))
	population = object@population
	solution = population[best.i[1],]
	return (solution)
}

select_pop <- function (object, r, q)
{
	if (missing(r))
		r <- 2 / (object@popSize * (object@popSize - 1))
	if (missing(q))
		q <- 2 / object@popSize
	rank <-
		(object@popSize + 1) - rank(object@fitness, ties.method = "min")
	prob <- 1 + q - (rank - 1) * r
	prob <- pmin(pmax(0, prob / sum(prob)), 1, na.rm = TRUE)
	sel <-
		sample(
			   1:object@popSize,
			   size = object@popSize,
			   prob = prob,
			   replace = TRUE
			   )
	out <- list(population = object@population[sel, , drop = FALSE],
				fitness = object@fitness[sel])
	return(out)
}

crossover_pop <- function (object, parents)
{
	fitness <- object@fitness[parents]
	parents <- object@population[parents, , drop = FALSE]
	parents[1,] = as.double(parents[1,])
	parents[2,] = as.double(parents[2,])
	n <- ncol(parents)
	children <- matrix(as.double(0), nrow = 2, ncol = n)
	fitnessChildren <- rep(NA, 2)

	#crossOverPoint <- sample(0:n, size = 1)
	if(sum(parents[1,]) != sum(parents[2,])) {
		message (paste0("Warning: parent 1 has diff num of parent 2: "), sum(parents[1,]), "---", sum(parents[2,]))
		print (paste(parents[1,], collapse = ","))
		print (paste(parents[2,], collapse = ","))
	}
	select.sum = sum(parents[1,])
	crossOverPoint <- sample(0:select.sum, size = 1)

	if (crossOverPoint == 0) {
		children[1:2, ] <- parents[2:1, ]
		fitnessChildren[1:2] <- fitness[2:1]
	}
	else if (crossOverPoint == select.sum) {
		children <- parents
		fitnessChildren <- fitness
	}
	else {
		p1.i = which(parents[1, ] == 1)
		p2.i = which(parents[2, ] == 1)
		c1.i = c(p1.i[1:crossOverPoint], p2.i[(crossOverPoint + 1):select.sum])
		c2.i = c(p2.i[1:crossOverPoint], p1.i[(crossOverPoint + 1):select.sum])
		#cat ("crossOverPoint: ", crossOverPoint, "\n")
		#cat ("Pre crossover parent: ", length(p1.i), " || " , length(p2.i), "\n")
		#cat ("Pre crossover child:  ", length(c1.i), " || " , length(c2.i), "\n")

		#process duplication
		dup.c1 = sum(duplicated(c1.i))
		dup.c2 = sum(duplicated(c2.i))
		if (dup.c1>0) {
			pool = setdiff(c(p1.i, p2.i), c1.i)
			c1.i = c(unique(c1.i), pool[1:dup.c1])            
		}
		if (dup.c2 > 0) {
			pool = setdiff(c(p1.i, p2.i), c2.i)
			c2.i = c(unique(c2.i), pool[1:dup.c2])
		}

		children[1, c1.i]  = 1
		children[2, c2.i]  = 1
		#cat ("Post crossover: ", length(c1.i), " || " , length(c2.i), "\n")
		stopifnot(length(c1.i) == select.sum)
		stopifnot(length(c2.i) == select.sum)
	}
	out <- list(children = children, fitness = fitnessChildren)
	return(out)
}

mutat_pop <- function (object, parent)
{
	mutate <- parent <- as.vector(object@population[parent,])
	# n <- length(parent)
	# j <- sample(1:n, size = 1)

	# select.sum = sum(parent)
	select.i = which(parent == 1)
	unselect.i = which(parent != 1)
	mutPoint.select <- sample(select.i, size = 1)
	mutPoint.unselect <- sample(unselect.i, size = 1)

	mutate[mutPoint.select] <- abs(mutate[mutPoint.select] - 1)
	mutate[mutPoint.unselect] <- abs(mutate[mutPoint.unselect] - 1)
	return(mutate)
}


