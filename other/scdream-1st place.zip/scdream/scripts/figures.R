rm(list=ls())

#setwd("~/Box Sync/April_work/Yale/Research/Single_cell/Dream_challenge/shared/scdream/figures")

load("../data/bin.bdt.rdata")
load("../data/cont.bdt.rdata")
load("../data/geometry.rdata")

add.alpha <- function(col, alpha = 1) {
  if (missing(col)) {
    stop("Please provide a vector of colours.")
  }
  ret = apply(sapply(col, col2rgb) / 255, 2,      function(x) {
    rgb(x[1], x[2], x[3], alpha = alpha)
  })
  return (as.character(ret))
}

grey.new<-add.alpha(col="grey",alpha=0.5)
red.new<-add.alpha(col="red",alpha=0.5)

#insitu continous graph
for (a in 1:7){
  png(paste0("bdt_cont_",a,".png"),width=3000,height=3000,pointsize = 50)
  par(mfrow=c(4,3),oma=c(5,4,0,0)+0.1,mar=c(0,0,0,0)+0.1)
  for (b in 1:12) {
    i=(a-1)*12+b
    #print(i)
    max_value = max(cont.bdt[,i])
    plot(
      x = geometry$xcoord,
      y = geometry$zcoord,
      col = rgb(max_value,max_value-cont.bdt[,i],max_value-cont.bdt[,i],maxColorValue=max_value),
      pch=20,
      cex=0.6,
      xlab = "",
      ylab = "",
      axes = F,
      xlim = c(-220, 220),
      ylim = c(-100, 100)
    )
    title(colnames(cont.bdt)[i],line=-1)
  }
  dev.off()
}

#insitu binary graph
for (a in 1:7){
  png(paste0("bdt_bin_",a,".png"),width=3000,height=3000,pointsize = 50)
  par(mfrow=c(4,3),oma=c(5,4,0,0)+0.1,mar=c(0,0,0,0)+0.1)
  for (b in 1:12) {
    i=(a-1)*12+b
    #print(i)
    col_vector<-rep(grey.new,length(bin.bdt[,i]))
    col_vector[which(bin.bdt[,i]==1)]<-red.new
    plot(
      x = geometry$xcoord,
      y = geometry$zcoord,
      col = col_vector,
      pch=20,
      cex=0.6,
      xlab = "",
      ylab = "",
      axes = F,
      xlim = c(-220, 220),
      ylim = c(-100, 100)
    )
    title(colnames(bin.bdt)[i],line=-1)
  }
  dev.off()
}