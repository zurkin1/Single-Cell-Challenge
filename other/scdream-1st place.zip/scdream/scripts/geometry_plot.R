rm(list=ls());

dat <- read.table(gzfile("geometry.txt.gz"), header=T);

out  <- kmeans(dat, 20);
cols <- rainbow(20, alpha=0.6);

library(scatterplot3d);
pdf("geometry_plot01.pdf", 12, 8);
scatterplot3d(dat$xcoord, y=dat$ycoord, z=dat$zcoord, pch=19, color=cols[out$cluster]);
dev.off();

library(rgl);
plot3d(dat$xcoord, y=dat$ycoord, z=dat$zcoord, col=cols[out$cluster], size=5, axes=F, xlab="", ylab="", zlab="", 
       ylim = c(-200, 200), zlim = c(-200, 200));
rgl.postscript("geometry_plot02.pdf","pdf");

dir.create("out", showWarnings = FALSE)
for (i in 1:90) {
  view3d(userMatrix=rotationMatrix(2*pi * i/90, 1, -1, -1))
  rgl.snapshot(filename=paste("out/frame-",
                              sprintf("%03d", i), ".png", sep=""))
}

system("convert -delay 5 -loop 0 out/frame*.png geometry_plot.gif");
