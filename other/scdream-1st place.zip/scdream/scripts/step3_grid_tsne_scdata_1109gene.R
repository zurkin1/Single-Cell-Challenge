rm(list=ls());
source("~/mybiotools/r/myfunc.R");
options("scipen"=1, "digits"=4, stringsAsFactors=FALSE);

source("/gpfs/ycga/project/fas/xu_ke/xz345/work/other/scdream/scripts/common.R", echo=T)

#library(scdream)
#data("geometry")

load("~/scdream/method2/sc.expr.space.rdata")
X= t(sc.expr.space)

perplexitys = c(5, 8, 12, 15, 30, 50)
max_iters = as.integer(seq(2000, 12000, length.out = 6))
Y=as.factor(rep("X1", dim(X)[1]))
pdffile.kw = "sc1109genes"
pch = c(19, 15, 16, 17, 18)
cex = 1
library(RColorBrewer)
cols = brewer.pal(n = 8, name = 'RdBu')
COLOR = c(cols[1], cols[8])
COLOR = c("darkgreen", "darkblue", COLOR)
threads = 20
myplot_tsne(X, 
			Y, 
			pdffile.kw, 
			perplexitys=perplexitys,
			max_iters=max_iters,
			pch=pch,
			cex=cex,
			threads = threads,
			COLOR=COLOR,
			)

