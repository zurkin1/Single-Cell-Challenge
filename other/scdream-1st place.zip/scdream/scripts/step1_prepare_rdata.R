#source("~/mybiotools/sc.raw/", echo=T)
rm(list=ls());
#source("~/mybiotools/sc.raw/myfunc.R");
options("scipen"=1, "digits"=4, stringsAsFactors=FALSE);

bin.bdt = read.csv("/gpfs/ycga/project/fas/xu_ke/xz345/work/other/scdream/rawdata/all_files/binarized_bdtnp.csv",T)
cont.bdt = read.table("/gpfs/ycga/project/fas/xu_ke/xz345/work/other/scdream/rawdata/all_files/bdtnp.txt",T)
dim(cont.bdt)
dim(bin.bdt)
geometry = read.table("/gpfs/ycga/project/fas/xu_ke/xz345/work/other/scdream/rawdata/all_files/geometry.txt", T)
head(geometry)
dim(geometry)
rem.i = which( geometry$ycoord < 0 )
geometry$ycoord[rem.i] = abs(geometry$ycoord[rem.i])

ls()
sc.norm= read.table("/gpfs/ycga/project/fas/xu_ke/xz345/work/other/scdream/rawdata/all_files/dge_normalized.txt",T)
head (geometry)
#geometry$merged = paste0(geometry[,1], "_", geometry[,2],"_", geometry[,3])
head (geometry)
#table(geometry$merged)
#length(table(geometry$merged))
length(table(geometry[,1]))
length(table(geometry[,2]))
length(table(geometry[,3]))
ls()
dim(sc.norm)
head(sc.norm[,1:5])
sc.raw= read.table("/gpfs/ycga/project/fas/xu_ke/xz345/work/other/scdream/rawdata/all_files/dge_raw.txt", F, row.names=1)
head(sc.raw[,1:5])
head(sc.norm[,1:5])
bin.sc.84g = read.csv("/gpfs/ycga/project/fas/xu_ke/xz345/work/other/scdream/rawdata/all_files/dge_binarized_distMap.csv",T)
head(bin.sc.84g[,1:3])
dim(bin.sc.84g)
setdiff(rownames(bin.sc.84g), rownames(sc.norm))
intersect(rownames(bin.sc.84g), rownames(sc.norm))
ls()
dim(bin.bdt)
dim(sc.norm)
dim(bin.sc.84g)
dim(cont.bdt)
dim(sc.raw)
dim(geometry)

gene.symbol.change <- function (x) {
	g.84.2 = rownames(x)
	g.84.2 = gsub("-|\\)|\\(|\\'",".",g.84.2,fixed = F)
	rownames(x) = g.84.2
	return (x)
}
sc.norm = gene.symbol.change(sc.norm)
setdiff(colnames(bin.bdt), rownames(sc.norm))
bin.sc.84g = gene.symbol.change(bin.sc.84g)
setdiff(colnames(bin.bdt), rownames(bin.sc.84g))
sc.raw = gene.symbol.change(sc.raw)
setdiff(colnames(bin.bdt), rownames(sc.raw))

library(limma)
sc.norm.quant = normalizeBetweenArrays(sc.raw)
setdiff(colnames(bin.bdt), rownames(sc.norm.quant))

genes = names(bin.bdt)
cont.sc.84g = sc.norm.quant[genes,]

save(cont.sc.84g, file="cont.sc.84g.rdata")
save(bin.bdt, file="bin.bdt.rdata")
save(sc.norm, file="sc.norm.rdata")
save(sc.norm.quant, file="sc.norm.quant.rdata")
save(bin.sc.84g, file="bin.sc.84g.rdata")
save(cont.bdt, file="cont.bdt.rdata")
save(sc.raw, file="sc.raw.rdata")
save(geometry, file="geometry.rdata")

if(F) {
	head(bin.bdt[,1:5])
	head(cont.bdt[,1:5])
	dim(cont.bdt)
	dim(geometry)
	head(geometry)
	cor.test(cont.bdt[,1], geometry[,1])
	cor.test(cont.bdt[,1], geometry[,2])
	cor.test(cont.bdt[,1], geometry[,3])
	cor.test(cont.bdt[,2], geometry[,1])
	cor.test(cont.bdt[,2], geometry[,2])
	cor.test(cont.bdt[,2], geometry[,3])
}

