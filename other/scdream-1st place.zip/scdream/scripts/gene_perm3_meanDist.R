#!/usr/bin/env Rscript
#using permutations instead of combinations

#rm(list=ls());
#source("~/mybiotools/r/myfunc.R");
options("scipen"=99, "digits"=4, stringsAsFactors=FALSE);

args<-commandArgs(T)

min.seed = as.numeric(args[1])
max.seed = as.numeric(args[2])
ifbin = as.logical(args[3])
CPUnum = as.numeric(args[4])

#################
#debug
#min.seed = 1
#max.seed = 100
#ifbin = F

#library(scdream)
#data(bin.bdt)
source("/gpfs/ycga/project/fas/xu_ke/xz345/soft/git/scdream/scripts/common.R", echo=T)

genes = names(bin.bdt)
cont.sc.84g = sc.norm.quant[genes,]
geometry1 = geometry

makeblock <- function (
					   max.d,
					   blocksize = 30,
					   min.d = 1,
					   ...) {
	n = max.d - min.d + 2
	blocksize = ifelse (blocksize<n, blocksize, n-1)
	pos = as.integer(seq(min.d, max.d+1, length.out=(blocksize+1)))
	block_num = length(pos) - 1
	return (list(block_num = block_num, start = pos[-length(pos)], end = pos[-1]-1, pos = pos))
}


performance1 <- function(genes) {
#for measuring gene comb's performance, No 1 of 2, Euclidean distance
	mapping_position = mapping(
			geneset_input = genes, 
			bin = ifbin,
			num_PS = 10,
			cont.sc.84g = cont.sc.84g
			)
	evalu.out = dist_evaluation(predicted_posi = mapping_position,
					idx=T,
					weighting=F,
					geometry1=geometry1,
					gold_coor=DistMap_coor)
	evalu.out$scoring
}

# require("parallel")
# CPUnum = 2

get_min.dist <- function (seeds=1:1000, #seed number
						 CPUnum = 30,
						 gene.num = 20,
						 fun = performance1,
						 ...) {
	library(doParallel)
	registerDoParallel(cores = CPUnum)
	n = length(seeds)
	#n = num.comb.max
	#blocksize = as.integer(n / (CPUnum + 1)) + 1
	block.out = makeblock(n, CPUnum*1.5, 1)
	block_num = block.out$block_num
	pos = block.out$pos
	output <- foreach (j = 1:block_num, .combine = rbind) %dopar%
	{
		start = pos[j]
		end = pos[j + 1] - 1
		out.s = c()
		for (i in start:end) {
			seed = seeds[i]
			set.seed(seed)
			gene.l = sample(genes, gene.num, replace=F)
			max.num = fun(gene.l)
			out.s = rbind(out.s, c(seed, max.num))
		}
		colnames(out.s) = c("seed", "min.dist.num")
		out.s
	}
	min.dist = min(output[,2], na.rm=T)
	max.i = which(output[,2] == min.dist)
	max.seed = output[max.i[1], 1]
	set.seed(max.seed)
	max.gene.l = sample(genes, gene.num, replace=F)
	return (list(gene=max.gene.l, min.dist = min.dist, seed = max.seed))
}

##########parameters###############
block.out = makeblock(max.seed, 5, min.seed)
block_num = block.out$block_num
(pos = block.out$pos)
##########parameters###############

do_min <- function(l) {
	m = do.call(c, l[[2]])
	min(m, na.rm=T)
}

gene.num = 60
l.g60 = vector("list", 3)
l.g60[[1]] = list()
l.g60[[2]] = list()
l.g60[[3]] = list()
names(l.g60) = c("gene", "min.dist.num", "seed")
for (j in 1:block_num)
{
	start = pos[j]
	end = pos[j + 1] - 1
	seeds = start:end
	print (paste0("Gene.num: ", gene.num, "; block: ", start, ":", end))
	max.out = get_min.dist(seeds=seeds, CPUnum=CPUnum, gene.num=gene.num, fun=performance1)
	l.g60[[1]][[length(l.g60[[1]])+1]] = max.out[[1]]
	l.g60[[2]][[length(l.g60[[2]])+1]] = max.out[[2]]
	l.g60[[3]][[length(l.g60[[3]])+1]] = max.out[[3]]
	print (do_min(l.g60))
}
save(l.g60, file=paste0(min.seed, "_", max.seed, "_ifbin", ifbin, "_mindist.g60.rdata"))

gene.num = 40
l.g40 = vector("list", 3)
l.g40[[1]] = list()
l.g40[[2]] = list()
l.g40[[3]] = list()
names(l.g40) = c("gene", "min.dist.num", "seed")
for (j in 1:block_num)
{
	start = pos[j]
	end = pos[j + 1] - 1
	seeds = start:end
	print (paste0("Gene.num: ", gene.num, "; block: ", start, ":", end))
	max.out = get_min.dist(seeds=seeds, CPUnum=CPUnum, gene.num=gene.num, fun=performance1)
	l.g40[[1]][[length(l.g40[[1]])+1]] = max.out[[1]]
	l.g40[[2]][[length(l.g40[[2]])+1]] = max.out[[2]]
	l.g40[[3]][[length(l.g40[[3]])+1]] = max.out[[3]]
	print (do_min(l.g40))
}
save(l.g40, file=paste0(min.seed, "_", max.seed, "_ifbin", ifbin, "_mindist.g40.rdata"))

gene.num = 20
l.g20 = vector("list", 3)
l.g20[[1]] = list()
l.g20[[2]] = list()
l.g20[[3]] = list()
names(l.g20) = c("gene", "min.dist.num", "seed")
for (j in 1:block_num)
{
	start = pos[j]
	end = pos[j + 1] - 1
	seeds = start:end
	print (paste0("Gene.num: ", gene.num, "; block: ", start, ":", end))
	max.out = get_min.dist(seeds=seeds, CPUnum=CPUnum, gene.num=gene.num, fun=performance1)
	l.g20[[1]][[length(l.g20[[1]])+1]] = max.out[[1]]
	l.g20[[2]][[length(l.g20[[2]])+1]] = max.out[[2]]
	l.g20[[3]][[length(l.g20[[3]])+1]] = max.out[[3]]
	print (do_min(l.g20))
}

#####debug
min.seed = 10001
max.seed = 10100
ifbin = T
CPUnum = 20

