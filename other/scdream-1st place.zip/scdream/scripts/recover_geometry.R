rm(list=ls());
source("~/mybiotools/r/myfunc.R");
options("scipen"=1, "digits"=4, stringsAsFactors=FALSE);

source("/gpfs/ycga/project/fas/xu_ke/xz345/work/other/scdream/scripts/common.R", echo=T)

#removing y < 0 training samples
rem.i = which( geometry$ycoord < 0 )
bin.bdt2 = bin.bdt[-rem.i, ]
cont.bdt2 = cont.bdt[-rem.i, ]
geometry2 = geometry[-rem.i,]

library(hash)

geometry2factor.all <- function(geometry2) {
	#no cut, using all as factor
	factor.y = paste("X", geometry2$xcoord, geometry2$ycoord, geometry2$zcoord, sep="_")
	Y = num2LetterFactor(factor.y)
	h = hash(keys=Y, values=factor.y)
	list(h, Y, factor.y)
}

out = geometry2factor.all(geometry2)
h = out[[1]]
hl = as.list(h)
Y = out[[2]]
fY = out[[3]]

pred = read.delim("prediction_results.txt",T)
library(dplyr)
#pred.p = pred %>% select(grep("prediction", names(pred)))
pred.p = pred %>% select(ends_with("prediction"))
pred.p2 = pred %>% select(-ends_with("prediction"))

pred.out = lapply(seq_along(pred.p), function(t) {
				  x = pred.p[,t]
				  x1 = as.vector(do.call(c, (hl[x])))
				  x2 = strsplit(x1, "_")
				  x3 = do.call(rbind, x2)
				  x4 = x3[,c(2,3,4)]
				  colnames(x4) = paste0(colnames(pred.p)[t], c(".xcoord", ".ycoord", ".zcoord"))
				  x4
} )

pred.out2 = do.call(cbind, pred.out)
output = data.frame(cbind(pred.p2, pred.out))
head(output)
w.table(output, file="prediction_results_coord.txt", T)



