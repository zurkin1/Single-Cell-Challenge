rm(list=ls())

#setwd("~/Box Sync/April_work/Yale/Research/Single_cell/Dream_challenge/shared/scdream/figures")

load("../data/bin.bdt.rdata")
load("../data/cont.bdt.rdata")
load("../data/geometry.rdata")

add.alpha <- function(col, alpha = 1) {
  if (missing(col)) {
    stop("Please provide a vector of colours.")
  }
  ret = apply(sapply(col, col2rgb) / 255, 2,      function(x) {
    rgb(x[1], x[2], x[3], alpha = alpha)
  })
  return (as.character(ret))
}

#new colours
grey.new<-add.alpha(col="grey",alpha=0.5)
red.new<-add.alpha(col="red",alpha=0.5)


#insitu continous graph

pdf(
  "bdt_cont_lateral.pdf",
  width = 20,
  height = 16,
  family = "ArialMT",
  pointsize = 20
)

par(
  mfrow = c(4, 3),
  oma = c(5, 4, 0, 0) + 0.1,
  mar = c(0, 0, 0, 0) + 0.1
)

for (i in 1:84) {
  max_value = max(cont.bdt[, i])
  plot(
    x = geometry$xcoord,
    y = geometry$zcoord,
    col = rgb(
      max_value,
      max_value - cont.bdt[, i],
      max_value - cont.bdt[, i],
      maxColorValue = max_value
    ),
    pch = 20,
    cex = 0.6,
    xlab = "",
    ylab = "",
    axes = F,
    xlim = c(-220, 220),
    ylim = c(-100, 100)
  )
  title(colnames(cont.bdt)[i], line = -1)
}
dev.off()


#insitu binary graph

pdf(
  "bdt_bin_lateral.pdf",
  width = 20,
  height = 16,
  family = "ArialMT",
  pointsize = 20
)

par(
  mfrow = c(4, 3),
  oma = c(5, 4, 0, 0) + 0.1,
  mar = c(0, 0, 0, 0) + 0.1
)

for (i in 1:84) {
  col_vector <- rep(grey.new, length(bin.bdt[, i]))
  col_vector[which(bin.bdt[, i] == 1)] <- red.new
  plot(
    x = geometry$xcoord,
    y = geometry$zcoord,
    col = col_vector,
    pch = 20,
    cex = 0.6,
    xlab = "",
    ylab = "",
    axes = F,
    xlim = c(-220, 220),
    ylim = c(-100, 100)
  )
  title(colnames(bin.bdt)[i], line = -1)
}
dev.off()


#plot continous - five views

pdf(
  "bdt_cont_five_views.pdf",
  width = 20,
  height = 16,
  family = "ArialMT",
  pointsize = 20
)

par(
  mfrow = c(6, 5),
  oma = c(5, 4, 0, 0) + 0.1,
  mar = c(0, 1, 1, 0) + 0.1
)

for (i in 1:84) {
  #plot 1: x,z
  input_column <- cont.bdt[, i]
  max_value = max(input_column)
  
  plot(
    x = geometry$xcoord,
    y = geometry$zcoord,
    col = rgb(
      max_value,
      max_value - input_column,
      max_value - input_column,
      maxColorValue = max_value
    ),
    pch = 20,
    cex = 0.4,
    axes = F,
    xlim = c(-220, 220),
    ylim = c(-100, 100),
    xlab = "",
    main = "lateral",
    ylab = colnames(cont.bdt)[i],
    cex.lab = 1.5,
    line = 0
  )
  
  #plot 2: x,y,z>0
  rows <- which(geometry$zcoord > 0)
  
  plot(
    x = geometry$xcoord[rows],
    y = -geometry$ycoord[rows],
    col = rgb(
      max_value,
      max_value - input_column[rows],
      max_value - input_column[rows],
      maxColorValue = max_value
    ),
    pch = 20,
    cex = 0.4,
    xlab = "",
    ylab = "",
    axes = F,
    xlim = c(-220, 220),
    ylim = c(-100, 100),
    main = "top",
    line = 0
    
  )
  
  #plot 3: x,y,z<=0
  rows <- which(geometry$zcoord <= 0)
  
  plot(
    x = geometry$xcoord[rows],
    y = geometry$ycoord[rows],
    col = rgb(
      max_value,
      max_value - input_column[rows],
      max_value - input_column[rows],
      maxColorValue = max_value
    ),
    pch = 20,
    cex = 0.4,
    xlab = "",
    ylab = "",
    axes = F,
    xlim = c(-220, 220),
    ylim = c(-100, 100),
    main = "bottom",
    line = 0
  )
  
  #plot 4: y,z,x<=0
  rows <- which(geometry$xcoord <= 0)
  
  plot(
    x = geometry$ycoord[rows],
    y = geometry$zcoord[rows],
    col = rgb(
      max_value,
      max_value - input_column[rows],
      max_value - input_column[rows],
      maxColorValue = max_value
    ),
    pch = 20,
    cex = 0.4,
    xlab = "",
    ylab = "",
    axes = F,
    xlim = c(-80 * 1.3, 80 * 1.3),
    ylim = c(-80, 70),
    main = "left",
    line = 0
  )
  
  
  #plot 5: y,z,x>0
  rows <- which(geometry$xcoord > 0)
  
  plot(
    x = -geometry$ycoord[rows],
    y = geometry$zcoord[rows],
    col = rgb(
      max_value,
      max_value - input_column[rows],
      max_value - input_column[rows],
      maxColorValue = max_value
    ),
    pch = 20,
    cex = 0.4,
    xlab = "",
    ylab = "",
    axes = F,
    xlim = c(-80 * 1.3, 80 * 1.3),
    ylim = c(-80, 70),
    main = "right",
    line = 0
  )
  
}

dev.off()

############################

#plot binary - five views

pdf(
  "bdt_bin_five_views.pdf",
  width = 20,
  height = 16,
  family = "ArialMT",
  pointsize = 20
)

par(
  mfrow = c(6, 5),
  oma = c(5, 4, 0, 0) + 0.1,
  mar = c(0, 1, 1, 0) + 0.1
)


for (i in 1:84) {
  #plot 1: x,z
  input_column <- bin.bdt[, i]
  
  col_vector <- rep(grey.new, length(input_column))
  col_vector[which(input_column == 1)] <- red.new
  
  plot(
    x = geometry$xcoord,
    y = geometry$zcoord,
    col = col_vector,
    pch = 20,
    cex = 0.4,
    axes = F,
    xlim = c(-220, 220),
    ylim = c(-100, 100),
    xlab = "",
    ylab = "",
    main = "lateral"
  )
  
  title (
    xlab = "",
    ylab = colnames(bin.bdt)[i],
    cex.lab = 1.5,
    line = 0
  )
  
  #plot 2: x,y,z>0
  rows <- which(geometry$zcoord > 0)
  #max_value = max(input_column[rows])
  
  input_column <- bin.bdt[rows, i]
  col_vector <- rep(grey.new, length(input_column[]))
  col_vector[which(input_column == 1)] <- red.new
  
  plot(
    x = geometry$xcoord[rows],
    y = -geometry$ycoord[rows],
    col = col_vector,
    pch = 20,
    cex = 0.4,
    xlab = "",
    ylab = "",
    axes = F,
    xlim = c(-220, 220),
    ylim = c(-100, 100),
    main = "top"
  )
  
  #plot 3: x,y,z<=0
  rows <- which(geometry$zcoord <= 0)
  
  input_column <- bin.bdt[rows, i]
  col_vector <- rep(grey.new, length(input_column[]))
  col_vector[which(input_column == 1)] <- red.new
  
  plot(
    x = geometry$xcoord[rows],
    y = geometry$ycoord[rows],
    col = col_vector,
    pch = 20,
    cex = 0.4,
    xlab = "",
    ylab = "",
    axes = F,
    xlim = c(-220, 220),
    ylim = c(-100, 100),
    main = "bottom"
  )
  
  #plot 4: y,z,x<=0
  
  rows <- which(geometry$xcoord <= 0)
  
  input_column <- bin.bdt[rows, i]
  col_vector <- rep(grey.new, length(input_column[]))
  col_vector[which(input_column == 1)] <- red.new
  
  plot(
    x = geometry$ycoord[rows],
    y = geometry$zcoord[rows],
    col = col_vector,
    pch = 20,
    cex = 0.4,
    xlab = "",
    ylab = "",
    axes = F,
    xlim = c(-80 * 1.3, 80 * 1.3),
    ylim = c(-80, 70),
    main = "left"
  )
  
  #plot 5: y,z,x>0
  
  rows <- which(geometry$xcoord > 0)
  
  input_column <- bin.bdt[rows, i]
  col_vector <- rep(grey.new, length(input_column[]))
  col_vector[which(input_column == 1)] <- red.new
  
  plot(
    x = -geometry$ycoord[rows],
    y = geometry$zcoord[rows],
    col = col_vector,
    pch = 20,
    cex = 0.4,
    xlab = "",
    ylab = "",
    axes = F,
    xlim = c(-80 * 1.3, 80 * 1.3),
    ylim = c(-80, 70),
    main = "right"
  )
}
dev.off()
  


