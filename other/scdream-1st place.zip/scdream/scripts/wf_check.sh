echo "g20"
cd /gpfs/ycga/scratch60/fas/xu_ke/xz345/work/scdream/perm_dist/GA/ML_GA/MLv5/g20
bash wf.sh | tail -n 10
echo "g40"
cd /gpfs/ycga/scratch60/fas/xu_ke/xz345/work/scdream/perm_dist/GA/ML_GA/MLv5/g40
bash wf.sh | tail -n 10
echo "g60"
cd /gpfs/ycga/scratch60/fas/xu_ke/xz345/work/scdream/perm_dist/GA/ML_GA/MLv5/g60
bash wf.sh | tail -n 10

