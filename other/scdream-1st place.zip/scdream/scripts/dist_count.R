rm(list=ls());

library(scdream)
data(cont.sc.84g)

dat.s<-cont.sc.84g

num   <- 85;
for (i in 1:70){
  num <- num - 1;
  dat.d <- dist(dat.s);
  dat.m <- as.matrix(dat.d);
  dat.n <- apply(dat.m, 1, sum);
  dat.i <- order(dat.n, decreasing = T);
  df    <- data.frame(order=1:num, gene=row.names(dat.m)[dat.i]);
  outf  <- paste0("out_cont/gene", num, ".txt");
  write.table(df, outf, quote=F, sep="\t", row.names=F);
  last.i <- tail(dat.i, n=1)
  dat.s <- dat.s[-last.i,];
}


