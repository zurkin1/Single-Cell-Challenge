rm(list=ls());
source("~/mybiotools/r/myfunc.R");
options("scipen"=1, "digits"=4, stringsAsFactors=FALSE);

source("/gpfs/ycga/project/fas/xu_ke/xz345/work/other/scdream/scripts/common.R", echo=T)

#library(scdream)
#data("geometry")

#load("sc.expr.space.rdata")

perplexitys = c(5, 8, 12, 15)
#perplexitys = c(8, 15, 50)
max_iters = as.integer(seq(100, 5000, length.out = 8))
max_iters = c(max_iters, 10000)
X = cont.bdt
Y=rep(NA, dim(X)[1])
Y[which(geometry$xcoord>0)] = "anterior"
Y[which(geometry$xcoord<=0)] = "posterior"
Y = as.factor(Y)
pdffile.kw = "headtail"
pch = c(19, 15, 16, 17, 18)
cex = 1
library(RColorBrewer)
cols = brewer.pal(n = 8, name = 'RdBu')
COLOR = c(cols[1], cols[8])
COLOR = c("darkgreen", "darkblue", COLOR)
threads = 20
myplot_tsne(X, 
			Y, 
			pdffile.kw, 
			perplexitys=perplexitys,
			max_iters=max_iters,
			pch=pch,
			cex=cex,
			threads = threads,
			COLOR=COLOR,
			)

