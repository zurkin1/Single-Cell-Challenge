check_Y <- function (Y) {
	l.Y = levels(Y)
	m.i = match(l.Y, Y)
	Y2 = Y
	if (sum(is.na(m.i))>0) {
		Y2 = as.character(Y)
		Y2 = as.factor(Y2)
	}
	Y2
}
