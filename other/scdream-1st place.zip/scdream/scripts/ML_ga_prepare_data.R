#source("~/mybiotools/r/", echo=T)
rm(list=ls());
source("~/mybiotools/r/myfunc.R");
options("scipen"=1, "digits"=4, stringsAsFactors=FALSE);

source("/gpfs/ycga/project/fas/xu_ke/xz345/work/other/scdream/scripts/common.R", echo=T)

X = t(cont.sc.84g)
Y1 = DistMap_coor[,1]
save(X, Y1, file="xcoord.rdata")
Y2 = DistMap_coor[,2]
save(X, Y2, file="ycoord.rdata")
Y3 = DistMap_coor[,3]
save(X, Y3, file="zcoord.rdata")


