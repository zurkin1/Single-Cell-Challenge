simi_dist_measures <- function(
							   driver, ##vector: 84 (genes) for the cell
							   insitu, ##matrix: 84 (genes) by 3039 (locations)
							   method="glm", ##c("glm","DistMap","cosine","manhattan","euclidean","maximum","pearson","kendall", "spearman")
							   num_most_positions=10, ##number of most likely positions
							   covariate=NULL, ##matrix: 84 (genes) by number of PCs 
							   ...){
	numpos=ncol(insitu)
	driver=as.vector(driver)
	if (!is.na(pmatch(method, "glm"))) 
		method <- "glm"
	METHODS <- c("glm","DistMap","cosine",
				 "manhattan","euclidean","maximum",
				 "pearson","kendall", "spearman")
	method <- pmatch(method, METHODS)
	if (is.na(method)) 
		stop("invalid distance method")
	if (method == -1) 
		stop("ambiguous distance method")
	method = METHODS[method]

	if(method=="glm"){
		if(is.null(covariate)){
			pv=sapply(1:numpos, function(i) 
					  summary(glm(driver~insitu[,i],family=gaussian))$coef[2,4])
		}else{
			covariate1=as.matrix(covariate)
			pv=sapply(1:numpos, function(i) 
					  summary(glm(driver~insitu[,i]+covariate1,family=gaussian))$coef[2,4])
		}
		#glm_pos=sort(pv, decreasing=F,index.return=TRUE)$ix[1:num_most_positions] 
		glm_pos1=sort(pv, decreasing=F,index.return=TRUE)
		glm_pos = glm_pos1$ix[1:num_most_positions] 
		return(list(glm_pv=pv,glm_position=glm_pos))
	}
	if(method=="cosine"){
		cosine_corr = sapply(1:numpos, function(i) 
							 sum(driver*insitu[,i])/sqrt(sum(driver^2)*sum(insitu[,i]^2)))
		cosine_pos=sort(cosine_corr, decreasing=T,index.return=TRUE)$ix[1:num_most_positions] 
		return(list(cosine_corr=cosine_corr,cosine_position=cosine_pos))
	}
	if(!is.na(pmatch(method,c("manhattan","euclidean","maximum")))){
		cont=t(cbind(driver,insitu))
		d=dist(cont, method = method, diag = FALSE, upper = FALSE)[1:numpos]
		dist_pos=sort(d, decreasing=F,index.return=TRUE)$ix[1:num_most_positions] 
		return(list(distance=d,distance_position=dist_pos))
	}
	if(!is.na(pmatch(method,c("pearson", "kendall", "spearman")))){
		correlation = sapply(1:numpos, function(i) 
							 abs(cor.test(driver, insitu[,i], method=method, exact = F)$estimate))
		names(correlation)=NULL
		correlation_pos=sort(correlation, decreasing=T,index.return=TRUE)$ix[1:num_most_positions] 
		return(list(correlation=correlation,correlation_position=correlation_pos))
	}
	if (method=="DistMap"){
		#library('mccr')
		mcc = sapply(1:numpos, function(i) 
					 mccr(driver, insitu[, i]))
		DistMap_pos= sort(mcc, decreasing=T,index.return=TRUE)$ix[1:num_most_positions]
		return(list(DistMap_score=mcc,DistMap_position=DistMap_pos))
	}
}
