rm(list = ls())

setwd("~/Box Sync/April_work/Yale/Research/Single_cell/Dream_challenge/Data")
source("../code/func_mapping_eval_corr.R")

load("geometry.rdata")
load("bin.sc.84g.rdata")
load("cont.sc.84g.rdata")
load("bin.bdt.rdata")
load("cont.bdt.rdata")
load("gold_cont_corr_matrix.rdata")
load("gold_bin_corr_matrix.rdata")

##avoid negative ys as outlier for correlation
geometry$ycoord<-abs(geometry$ycoord)

##test

test<-c("Btk29A","tkv","eve","pxb", "trn","E.spl.m5.HLH","ImpL2","ftz", "h","nub","D","MESR3", "dpn","tll","Traf4","CG8147", "toc","CG14427","rau","Esp" )
output_mapping<-mapping_distmap(test,1)
dim(output_mapping)

compare<-eval_corr_cont(output_mapping)
compare<-eval_corr_bin(output_mapping)

mean(apply(compare,2,mean))
apply(compare,2,hist)

mean(compare)

##run on summary data
load("gene_subset_summary_1.rdata")

gene_subset_summary_1$eval_corr_bin<-NA
gene_subset_summary_1$eval_corr_cont<-NA

for (i in 2:nrow(gene_subset_summary_1)) {
  genes <- unlist(strsplit(gene_subset_summary_1$gene_set[i], split = ","))
  output_mapping <- mapping_distmap(genes, 1)
  gene_subset_summary_1[i, c("eval_corr_bin")] <-mean(apply(eval_corr_bin(output_mapping),2,mean,na.rm=TRUE),na.rm=TRUE)
  gene_subset_summary_1[i, c("eval_corr_cont")] <-mean(apply(eval_corr_cont(output_mapping),2,mean,na.rm=TRUE),na.rm=TRUE)
  print(i)
}

n<-which(is.na(gene_subset_summary_1$eval_corr_bin))
n<-n[-1]

for (i in n) {
  genes <- unlist(strsplit(gene_subset_summary_1$gene_set[i], split = ","))
  output_mapping <- mapping_distmap(genes, 1)
  gene_subset_summary_1[i, c("eval_corr_bin")] <-mean(apply(eval_corr_bin(output_mapping),2,mean,na.rm=TRUE),na.rm=TRUE)
  gene_subset_summary_1[i, c("eval_corr_cont")] <-mean(apply(eval_corr_cont(output_mapping),2,mean,na.rm=TRUE),na.rm=TRUE)
  print(i)
}

gene_subset_summary_2<-gene_subset_summary_1

save(gene_subset_summary_2,file="gene_subset_summary_2.rdata")


