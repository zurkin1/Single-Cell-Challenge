
library(scdream)
data(bin.bdt)
data(bin.sc.84g)
data(cont.sc.84g)
data(cont.bdt)
data(geometry)
data(geometry.all)
data(sc.norm)
data(sc.norm.quant)
data(sc.raw)
data(DistMap_coor)
data(DistMap_coor_new)
data(gene_subset_summary)
data(cont.sc.84g)
data(gold_bin_corr_matrix)

source("/gpfs/ycga/project/fas/xu_ke/xz345/soft/git/scdream/R/simi_dist_measures.R")
source("/gpfs/ycga/project/fas/xu_ke/xz345/soft/git/scdream/R/dist_evaluation.R")
source("/gpfs/ycga/project/fas/xu_ke/xz345/soft/git/scdream/R/func_eval_corr.R")
source("/gpfs/ycga/project/fas/xu_ke/xz345/soft/git/scdream/scripts/mapping.R")
source("/gpfs/ycga/project/fas/xu_ke/xz345/soft/git/scdream/R/func_mapping_eval_corr.R")
source("/gpfs/ycga/project/fas/xu_ke/xz345/soft/git/scdream/R/gene_eval.R")
source("/gpfs/ycga/project/fas/xu_ke/xz345/soft/git/scdream/R/sc24groups.R")
source("/gpfs/ycga/project/fas/xu_ke/xz345/soft/git/scdream/R/dream_mapping_method.R")



