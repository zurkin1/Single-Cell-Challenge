build_forest_predict_hpc_fork <-
	function(trainX,
			 trainY,
			 n_tree,
			 m_feature,
			 min_leaf,
			 CPUnum = 20, #threads
			 seed = 123, #random seed
			 cv.fold = NULL, #numeric, cross validation, DF: null
			 #if !is.null(cv.fold), testX has to be equal to trainX
			 testX) {
		#wrapping function for build_forest_predict_hpc
		# fork each porcess to a gingle node

		queue = "general"
		comm.mem = "120000M"

		fork_script = "/gpfs/ycga/project/fas/xu_ke/xz345/soft/git/scdream/scripts/hpc_fork.R"
		kw = paste0("_temp_", sample(1:100000,1) + sample(100000:200000,1))
		in_rdata = paste0(kw, ".rdata")
		out_rdata = paste0(kw, "_out.rdata")

		save(trainX, trainY, n_tree, m_feature, min_leaf, CPUnum, seed, cv.fold, testX, file=in_rdata)
		CMD = paste("Rscript --max-ppsize=500000", fork_script, in_rdata, out_rdata, sep=" ")
		while (!file.exists(out_rdata)) {
			cat ("CMD: ", CMD, "\n", sep="")
			pbsid = system(paste0("pbsv2.pl \"", CMD, "\"  -ppn ", CPUnum, " -q ", queue, " -pmem ", comm.mem), intern=T)

			CMD = paste0("check_pbs_state.pl ", pbsid)
			cat ("CMD: ", CMD, "\n", sep="")
			system(CMD, intern=T)
		}
		load(out_rdata)
		CMD = paste("rm -fr", in_rdata, out_rdata, sep = " ")
		system(CMD, intern=T)
		return (mapping_position)
	}

